#!/bin/bash
# AMLyricsBTW — クライアント Swiftファイル生成スクリプト
# Xcodeプロジェクトの AMLyricsBTW/ フォルダ内で実行すること

set -e
echo "🎵 AMLyricsBTW クライアントファイル生成開始..."

# プロジェクト名（Xcodeで作成したフォルダ名に合わせる）
APP_DIR="${1:-AMLyricsBTW}"

mkdir -p "$APP_DIR/Models"
mkdir -p "$APP_DIR/Views"
mkdir -p "$APP_DIR/Managers"
mkdir -p "$APP_DIR/SwiftData"
mkdir -p "$APP_DIR/Utilities"

# ══════════════════════════════════════════════════════════════════════════════
# Models/LyricsModels.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Models/LyricsModels.swift" << 'SWIFT_EOF'
import Foundation

// MARK: - Data Models

struct WordTimestamp: Codable, Sendable {
    let word: String
    let start: Double
    let end: Double
}

struct LyricsLine: Codable, Sendable, Identifiable {
    var id: Int { lineIndex }
    let lineIndex: Int
    let start: Double
    let end: Double
    let text: String
    let translation: String
    let words: [WordTimestamp]?

    enum CodingKeys: String, CodingKey {
        case lineIndex  = "line_index"
        case start, end, text, translation, words
    }

    var hasFavoriteWords: Bool { !(words?.isEmpty ?? true) }
}

struct TrackLyrics: Codable, Sendable {
    let trackId: String
    let title: String
    let artist: String
    let silenceOffset: Double
    let lyrics: [LyricsLine]

    enum CodingKeys: String, CodingKey {
        case trackId       = "track_id"
        case title, artist
        case silenceOffset = "silence_offset"
        case lyrics
    }
}

// MARK: - API Response Models

struct JobResponse: Codable, Sendable {
    let jobId: String
    let status: String

    enum CodingKeys: String, CodingKey {
        case jobId = "job_id"
        case status
    }
}

struct JobStatusResponse: Codable, Sendable {
    let jobId: String
    let status: String
    let result: TrackLyrics?
    let error: String?

    enum CodingKeys: String, CodingKey {
        case jobId = "job_id"
        case status, result, error
    }
}

struct QueueStatus: Codable, Sendable {
    let waiting: Int
    let current: String?
    let totalJobs: Int

    enum CodingKeys: String, CodingKey {
        case waiting, current
        case totalJobs = "total_jobs"
    }
}

// MARK: - Spotify Lyric API

struct SpotifyLyricsResponse: Codable, Sendable {
    let lines: [SpotifyLine]?
    let syncType: String?

    enum CodingKeys: String, CodingKey {
        case lines
        case syncType = "syncType"
    }
}

struct SpotifyLine: Codable, Sendable {
    let startTimeMs: String?
    let words: String?
    let syllables: [String]?
    let endTimeMs: String?
}

// MARK: - Mock Data for Previews

extension TrackLyrics {
    static let mock = TrackLyrics(
        trackId: "preview_001",
        title: "N.Y. State of Mind",
        artist: "Nas",
        silenceOffset: 0.42,
        lyrics: [
            LyricsLine(
                lineIndex: 0, start: 12.34, end: 14.80,
                text: "I never sleep, 'cause sleep is the cousin of death",
                translation: "眠らない、眠りは死の従兄弟だから",
                words: [
                    WordTimestamp(word: "I",      start: 12.34, end: 12.45),
                    WordTimestamp(word: "never",  start: 12.46, end: 12.70),
                    WordTimestamp(word: "sleep,", start: 12.71, end: 13.00),
                    WordTimestamp(word: "'cause", start: 13.10, end: 13.30),
                    WordTimestamp(word: "sleep",  start: 13.31, end: 13.55),
                    WordTimestamp(word: "is",     start: 13.56, end: 13.65),
                    WordTimestamp(word: "the",    start: 13.66, end: 13.75),
                    WordTimestamp(word: "cousin", start: 13.76, end: 14.10),
                    WordTimestamp(word: "of",     start: 14.11, end: 14.20),
                    WordTimestamp(word: "death",  start: 14.21, end: 14.80),
                ]
            ),
            LyricsLine(
                lineIndex: 1, start: 15.00, end: 17.50,
                text: "Beyond the walls of intelligence, life is defined",
                translation: "知性の壁を超えたところで、人生の意味が決まる",
                words: nil
            ),
            LyricsLine(
                lineIndex: 2, start: 18.00, end: 20.50,
                text: "I think of crime when I'm in a New York state of mind",
                translation: "ニューヨークの空気に包まれると、頭に浮かぶのは街の影",
                words: nil
            ),
        ]
    )
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Utilities/ColorExtractor.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Utilities/ColorExtractor.swift" << 'SWIFT_EOF'
import AppKit
import CoreImage
import SwiftUI

// MARK: - Dominant Color Extractor

@MainActor
final class ColorExtractor {

    /// NSImageから支配的な色を最大3色抽出する
    static func extract(from image: NSImage, count: Int = 3) -> [Color] {
        guard let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            return defaultColors()
        }

        // サムネイルサイズに縮小してパフォーマンス向上
        let size = CGSize(width: 50, height: 50)
        guard let thumbnail = resized(cgImage, to: size) else {
            return defaultColors()
        }

        let pixels = extractPixels(from: thumbnail)
        let dominant = kMeansColors(pixels: pixels, k: count)

        let colors = dominant.map { rgb -> Color in
            var r = rgb.0, g = rgb.1, b = rgb.2
            // 暗すぎる場合（輝度 < 0.2）を自動補正
            let luminance = 0.299 * r + 0.587 * g + 0.114 * b
            if luminance < 0.2 {
                let boost: CGFloat = 0.3
                r = min(1.0, r + boost)
                g = min(1.0, g + boost)
                b = min(1.0, b + boost)
            }
            return Color(red: r, green: g, blue: b)
        }

        return colors.isEmpty ? defaultColors() : colors
    }

    // MARK: Private

    private static func defaultColors() -> [Color] {
        [Color(red: 0.1, green: 0.1, blue: 0.2),
         Color(red: 0.2, green: 0.1, blue: 0.3),
         Color(red: 0.05, green: 0.05, blue: 0.15)]
    }

    private static func resized(_ cgImage: CGImage, to size: CGSize) -> CGImage? {
        let context = CGContext(
            data: nil,
            width: Int(size.width), height: Int(size.height),
            bitsPerComponent: 8, bytesPerRow: 0,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        )
        context?.draw(cgImage, in: CGRect(origin: .zero, size: size))
        return context?.makeImage()
    }

    private static func extractPixels(from cgImage: CGImage) -> [(CGFloat, CGFloat, CGFloat)] {
        let width = cgImage.width, height = cgImage.height
        var pixels: [(CGFloat, CGFloat, CGFloat)] = []
        pixels.reserveCapacity(width * height)

        guard let data = cgImage.dataProvider?.data,
              let ptr = CFDataGetBytePtr(data) else { return pixels }

        let bytesPerPixel = cgImage.bitsPerPixel / 8
        for y in 0..<height {
            for x in 0..<width {
                let offset = (y * cgImage.bytesPerRow) + (x * bytesPerPixel)
                let r = CGFloat(ptr[offset])     / 255
                let g = CGFloat(ptr[offset + 1]) / 255
                let b = CGFloat(ptr[offset + 2]) / 255
                pixels.append((r, g, b))
            }
        }
        return pixels
    }

    /// 簡易k-meansクラスタリング（k=3, iter=10）
    private static func kMeansColors(
        pixels: [(CGFloat, CGFloat, CGFloat)],
        k: Int
    ) -> [(CGFloat, CGFloat, CGFloat)] {
        guard pixels.count >= k else { return pixels }

        // 初期中心: 均等に分散
        var centers: [(CGFloat, CGFloat, CGFloat)] = (0..<k).map { i in
            pixels[(pixels.count / k) * i]
        }

        for _ in 0..<10 {
            var sums = Array(repeating: (CGFloat(0), CGFloat(0), CGFloat(0), 0), count: k)
            for px in pixels {
                var minDist = CGFloat.infinity
                var minIdx  = 0
                for (ci, c) in centers.enumerated() {
                    let d = dist(px, c)
                    if d < minDist { minDist = d; minIdx = ci }
                }
                sums[minIdx].0 += px.0
                sums[minIdx].1 += px.1
                sums[minIdx].2 += px.2
                sums[minIdx].3 += 1
            }
            centers = sums.map { s in
                let n = max(1, CGFloat(s.3))
                return (s.0 / n, s.1 / n, s.2 / n)
            }
        }
        return centers
    }

    private static func dist(
        _ a: (CGFloat, CGFloat, CGFloat),
        _ b: (CGFloat, CGFloat, CGFloat)
    ) -> CGFloat {
        let dr = a.0 - b.0, dg = a.1 - b.1, db = a.2 - b.2
        return dr*dr + dg*dg + db*db
    }
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# SwiftData/CachedLyrics.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/SwiftData/CachedLyrics.swift" << 'SWIFT_EOF'
import Foundation
import SwiftData

@Model
final class CachedLyrics {
    @Attribute(.unique) var trackId: String
    var title: String
    var artist: String
    var lyricsJSON: Data
    var cachedAt: Date
    var isFavorite: Bool

    init(trackId: String, title: String, artist: String, lyricsJSON: Data, isFavorite: Bool = false) {
        self.trackId   = trackId
        self.title     = title
        self.artist    = artist
        self.lyricsJSON = lyricsJSON
        self.cachedAt  = Date()
        self.isFavorite = isFavorite
    }

    func decode() -> TrackLyrics? {
        try? JSONDecoder().decode(TrackLyrics.self, from: lyricsJSON)
    }

    /// 30日以上古いキャッシュを削除
    static func purgeOld(context: ModelContext) {
        let cutoff = Date().addingTimeInterval(-30 * 24 * 3600)
        let pred   = #Predicate<CachedLyrics> { $0.cachedAt < cutoff }
        try? context.delete(model: CachedLyrics.self, where: pred)
    }
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Managers/ServerClient.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Managers/ServerClient.swift" << 'SWIFT_EOF'
import Foundation

// MARK: - Server Client

actor ServerClient {

    // UserDefaults で設定
    static let shared = ServerClient()

    private var baseURL: String {
        UserDefaults.standard.string(forKey: "serverBaseURL") ?? "http://192.168.1.100:8000"
    }
    private var apiKey: String {
        UserDefaults.standard.string(forKey: "serverAPIKey") ?? ""
    }

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest  = 30
        config.timeoutIntervalForResource = 120
        return URLSession(configuration: config)
    }()

    // MARK: - Public API

    func analyzeTrack(
        trackId: String, title: String, artist: String, isFavorite: Bool
    ) async throws -> JobResponse {
        let body: [String: Any] = [
            "track_id":    trackId,
            "title":       title,
            "artist":      artist,
            "is_favorite": isFavorite,
        ]
        return try await post("/analyze", body: body)
    }

    func getJobStatus(jobId: String) async throws -> JobStatusResponse {
        try await get("/status/\(jobId)")
    }

    func getCachedLyrics(trackId: String) async throws -> TrackLyrics {
        try await get("/cache/\(trackId)")
    }

    func getQueueStatus() async throws -> QueueStatus {
        try await get("/queue")
    }

    // MARK: - Private Helpers

    private func request(path: String, method: String, body: [String: Any]? = nil) throws -> URLRequest {
        guard let url = URL(string: baseURL + path) else {
            throw URLError(.badURL)
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(apiKey, forHTTPHeaderField: "X-API-Key")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let body {
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        return req
    }

    private func get<T: Decodable>(_ path: String) async throws -> T {
        let req = try request(path: path, method: "GET")
        return try await execute(req)
    }

    private func post<T: Decodable>(_ path: String, body: [String: Any]) async throws -> T {
        let req = try request(path: path, method: "POST", body: body)
        return try await execute(req)
    }

    private func execute<T: Decodable>(_ req: URLRequest) async throws -> T {
        for attempt in 0..<2 {
            do {
                let (data, response) = try await session.data(for: req)
                guard let http = response as? HTTPURLResponse else {
                    throw URLError(.badServerResponse)
                }
                guard (200..<300).contains(http.statusCode) else {
                    throw URLError(.badServerResponse)
                }
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                if attempt == 0 {
                    try await Task.sleep(for: .seconds(3))
                } else {
                    throw error
                }
            }
        }
        throw URLError(.cannotConnectToHost)
    }
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Managers/SyncClock.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Managers/SyncClock.swift" << 'SWIFT_EOF'
import Foundation
import MusicKit
import QuartzCore
import Observation

// NOTE: Info.plist に NSAppleMusicUsageDescription キーを追加してください。
// 例: "歌詞の同期表示のためにApple Musicへのアクセスが必要です"

// MARK: - Sync Clock

@Observable
@MainActor
final class SyncClock {

    // ── Published State ──────────────────────────────────────────────────────
    private(set) var currentTime: Double     = 0.0   // 補正済み再生時刻（秒）
    private(set) var currentLineIndex: Int   = -1
    private(set) var isPlaying: Bool         = false

    /// 手動タイミング補正値（AppStorageとは別に保持し外部から設定）
    var userOffset: Double = 0.0

    // ── Internal ─────────────────────────────────────────────────────────────
    private var displayLink: CADisplayLink?
    private var lyrics: TrackLyrics?

    // MARK: - Public

    func attach(lyrics: TrackLyrics) {
        self.lyrics = lyrics
        currentLineIndex = -1
    }

    func startMonitoring() {
        stopMonitoring()
        let link = CADisplayLink(target: self, selector: #selector(tick))
        link.add(to: .main, forMode: .common)
        displayLink = link

        // 再生状態監視
        Task {
            for await state in MusicKit.MusicPlayer.State.updates {
                await MainActor.run {
                    isPlaying = state.playbackStatus == .playing
                }
            }
        }
    }

    func stopMonitoring() {
        displayLink?.invalidate()
        displayLink = nil
    }

    // MARK: - CADisplayLink Tick

    @objc private func tick(_ link: CADisplayLink) {
        let rawTime = ApplicationMusicPlayer.shared.playbackTime
        let adjusted = rawTime + userOffset - (lyrics?.silenceOffset ?? 0.0)
        currentTime  = adjusted
        currentLineIndex = findCurrentLine(at: adjusted)
    }

    // MARK: - Line Detection

    private func findCurrentLine(at time: Double) -> Int {
        guard let lines = lyrics?.lyrics, !lines.isEmpty else { return -1 }

        // 二分探索
        var lo = 0, hi = lines.count - 1
        while lo <= hi {
            let mid = (lo + hi) / 2
            let line = lines[mid]
            if time < line.start        { hi = mid - 1 }
            else if time > line.end + 0.5 { lo = mid + 1 }
            else { return mid }
        }
        // 次の行の手前ならアクティブな行なし
        return -1
    }

    /// 指定行内での単語進捗（0.0 〜 1.0）
    func wordProgress(for line: LyricsLine, at time: Double) -> Double {
        guard let words = line.words, !words.isEmpty else { return 0 }
        let completedWords = words.filter { time >= $0.end }.count
        return Double(completedWords) / Double(words.count)
    }

    /// 特定の単語の塗りつぶし進捗（0.0 = 未到達, 1.0 = 完了）
    func fillProgress(for word: WordTimestamp, at time: Double) -> Double {
        guard word.end > word.start else { return time >= word.start ? 1.0 : 0.0 }
        let progress = (time - word.start) / (word.end - word.start)
        return max(0.0, min(1.0, progress))
    }
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Managers/LyricProvider.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Managers/LyricProvider.swift" << 'SWIFT_EOF'
import Foundation
import MusicKit
import Observation
import SwiftData

// NOTE: Spotify-Lyric-API は Spotify Track ID が必要です。
// Apple MusicとSpotifyのIDは別物なので、必要に応じてISRC等で変換してください。

// MARK: - Loading State

enum LyricLoadState: Sendable {
    case idle, loading, analyzing(progress: String), done, error(String)
}

// MARK: - Lyric Provider

@Observable
@MainActor
final class LyricProvider {

    private(set) var state:  LyricLoadState = .idle
    private(set) var lyrics: TrackLyrics?

    private var modelContext: ModelContext?

    func configure(context: ModelContext) {
        modelContext = context
        CachedLyrics.purgeOld(context: context)
    }

    // MARK: - Main Entry Point

    func loadLyrics(for song: Song, isFavorite: Bool) async {
        guard let trackId = song.id.rawValue as? String else { return }
        let title  = song.title
        let artist = song.artistName

        state = .loading
        lyrics = nil

        // ① ローカルキャッシュ
        if let cached = fetchLocal(trackId: trackId) {
            lyrics = cached
            state  = .done
            return
        }

        // ② サーバーキャッシュ
        if let remote = try? await ServerClient.shared.getCachedLyrics(trackId: trackId) {
            saveLocal(remote, isFavorite: isFavorite)
            lyrics = remote
            state  = .done
            return
        }

        // ③ 新規解析
        do {
            state = .analyzing(progress: "解析リクエスト送信中...")
            let job = try await ServerClient.shared.analyzeTrack(
                trackId: trackId, title: title, artist: artist, isFavorite: isFavorite
            )

            if job.status == "done", let cached = try? await ServerClient.shared.getCachedLyrics(trackId: trackId) {
                saveLocal(cached, isFavorite: isFavorite)
                lyrics = cached
                state  = .done
                return
            }

            // ポーリング（3秒間隔、最大10分）
            let deadline = Date().addingTimeInterval(600)
            while Date() < deadline {
                try await Task.sleep(for: .seconds(3))
                let status = try await ServerClient.shared.getJobStatus(jobId: job.jobId)
                state = .analyzing(progress: "解析中... (ステータス: \(status.status))")

                if status.status == "done", let result = status.result {
                    saveLocal(result, isFavorite: isFavorite)
                    lyrics = result
                    state  = .done
                    return
                } else if status.status == "error" {
                    throw NSError(domain: "LyricProvider", code: 1,
                                  userInfo: [NSLocalizedDescriptionKey: status.error ?? "Unknown"])
                }
            }
            throw NSError(domain: "LyricProvider", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "タイムアウト"])

        } catch {
            // ④ Spotifyフォールバック（wordsなし）
            state = .analyzing(progress: "Spotifyからフォールバック中...")
            if let fallback = await loadFromSpotify(title: title, artist: artist, trackId: trackId) {
                saveLocal(fallback, isFavorite: false)
                lyrics = fallback
                state  = .done
            } else {
                state = .error(error.localizedDescription)
            }
        }
    }

    // MARK: - Local Cache (SwiftData)

    private func fetchLocal(trackId: String) -> TrackLyrics? {
        guard let ctx = modelContext else { return nil }
        let pred = #Predicate<CachedLyrics> { $0.trackId == trackId }
        let desc = FetchDescriptor(predicate: pred)
        return (try? ctx.fetch(desc))?.first?.decode()
    }

    private func saveLocal(_ track: TrackLyrics, isFavorite: Bool) {
        guard let ctx = modelContext,
              let data = try? JSONEncoder().encode(track) else { return }

        // 既存レコードを上書き
        let id = track.trackId
        let pred = #Predicate<CachedLyrics> { $0.trackId == id }
        let desc = FetchDescriptor(predicate: pred)
        if let existing = (try? ctx.fetch(desc))?.first {
            existing.lyricsJSON  = data
            existing.cachedAt    = Date()
            existing.isFavorite  = isFavorite
        } else {
            let obj = CachedLyrics(
                trackId: track.trackId, title: track.title,
                artist: track.artist, lyricsJSON: data, isFavorite: isFavorite
            )
            ctx.insert(obj)
        }
        try? ctx.save()
    }

    // MARK: - Spotify Fallback

    private func loadFromSpotify(title: String, artist: String, trackId: String) async -> TrackLyrics? {
        // Spotify Track IDが必要（ここでは trackId をそのまま試みる）
        guard let url = URL(string: "https://spotify-lyric-api-984e7b4face0.herokuapp.com/?trackid=\(trackId)") else {
            return nil
        }
        guard let (data, _) = try? await URLSession.shared.data(from: url),
              let resp = try? JSONDecoder().decode(SpotifyLyricsResponse.self, from: data),
              let lines = resp.lines else { return nil }

        let lyricsLines = lines.enumerated().compactMap { (idx, line) -> LyricsLine? in
            guard let text = line.words, !text.isEmpty else { return nil }
            let startMs = Double(line.startTimeMs ?? "0") ?? 0
            let endMs   = Double(line.endTimeMs   ?? "0") ?? 0
            return LyricsLine(
                lineIndex: idx,
                start: startMs / 1000,
                end:   endMs   / 1000,
                text:  text,
                translation: "",
                words: nil
            )
        }

        return TrackLyrics(
            trackId: trackId, title: title, artist: artist,
            silenceOffset: 0, lyrics: lyricsLines
        )
    }
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Views/LyricsModels.swift — VisualEffectView (Liquid Glass Helper)
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Utilities/GlassEffect.swift" << 'SWIFT_EOF'
import AppKit
import SwiftUI

// MARK: - NSVisualEffectView Wrapper (Liquid Glass Base)

struct VisualEffectBlur: NSViewRepresentable {
    var material: NSVisualEffectView.Material
    var blendingMode: NSVisualEffectView.BlendingMode

    func makeNSView(context: Context) -> NSVisualEffectView {
        let v = NSVisualEffectView()
        v.material     = material
        v.blendingMode = blendingMode
        v.state        = .active
        return v
    }
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        nsView.material     = material
        nsView.blendingMode = blendingMode
    }
}

// MARK: - Glass Card Modifier

struct GlassCard: ViewModifier {
    var cornerRadius: CGFloat = 18
    var opacity: Double       = 0.18

    func body(content: Content) -> some View {
        content
            .background {
                ZStack {
                    VisualEffectBlur(material: .hudWindow, blendingMode: .withinWindow)
                    Color.white.opacity(opacity)
                }
                .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            }
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: [.white.opacity(0.4), .white.opacity(0.05)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 0.8
                    )
            }
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
    }
}

extension View {
    func glassCard(cornerRadius: CGFloat = 18, opacity: Double = 0.18) -> some View {
        modifier(GlassCard(cornerRadius: cornerRadius, opacity: opacity))
    }
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Views/KaraokeLineView.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Views/KaraokeLineView.swift" << 'SWIFT_EOF'
import SwiftUI

// MARK: - Karaoke Line View (Word-level fill animation)

struct KaraokeLineView: View {
    let line: LyricsLine
    let currentTime: Double
    let isActive: Bool
    let clock: SyncClock

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            // ── オリジナル歌詞（カラオケ塗りつぶし）──────────────────────────
            if let words = line.words {
                WordsFillRow(words: words, currentTime: currentTime, clock: clock)
            } else {
                Text(line.text)
                    .font(.system(size: 20, weight: .semibold, design: .rounded))
                    .foregroundStyle(isActive ? .white : .white.opacity(0.4))
            }

            // ── 意訳 ─────────────────────────────────────────────────────────
            if !line.translation.isEmpty {
                Text(line.translation)
                    .font(.system(size: 13, weight: .regular, design: .rounded))
                    .foregroundStyle(isActive ? Color.white.opacity(0.7) : Color.white.opacity(0.25))
                    .padding(.top, 1)
            }
        }
        .opacity(isActive ? 1.0 : 0.4)
        .animation(.easeInOut(duration: 0.25), value: isActive)
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
    }
}

// MARK: - Words Fill Row

private struct WordsFillRow: View {
    let words: [WordTimestamp]
    let currentTime: Double
    let clock: SyncClock

    var body: some View {
        // FlowLayout風: HStackで折り返しは非対応なので、とりあえず単純HStack
        HStack(spacing: 4) {
            ForEach(words, id: \.word) { word in
                WordFillView(word: word, progress: clock.fillProgress(for: word, at: currentTime))
            }
        }
    }
}

// MARK: - Single Word Fill View

private struct WordFillView: View {
    let word: WordTimestamp
    let progress: Double   // 0.0 〜 1.0

    var body: some View {
        ZStack(alignment: .leading) {
            // 下レイヤー: グレー（未再生）
            Text(word.word)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundStyle(Color.white.opacity(0.25))

            // 上レイヤー: 白 + clipShape で左から右へ塗りつぶし
            Text(word.word)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundStyle(
                    LinearGradient(
                        colors: [Color.white, Color(red: 0.9, green: 0.85, blue: 1.0)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .overlay(alignment: .leading) {
                    GeometryReader { geo in
                        Color.clear.preference(
                            key: WordWidthKey.self,
                            value: geo.size.width
                        )
                    }
                }
                .mask(alignment: .leading) {
                    GeometryReader { geo in
                        Rectangle()
                            .frame(width: geo.size.width * progress)
                            .animation(.linear(duration: max(0, word.end - word.start)), value: progress)
                    }
                }
        }
    }
}

private struct WordWidthKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

// MARK: - Preview

#Preview {
    KaraokeLineView(
        line: TrackLyrics.mock.lyrics[0],
        currentTime: 13.0,
        isActive: true,
        clock: SyncClock()
    )
    .frame(width: 600)
    .background(Color.black)
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Views/LyricsLineView.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Views/LyricsLineView.swift" << 'SWIFT_EOF'
import SwiftUI

// MARK: - Normal Lyrics Line (highlight mode, no word timestamps)

struct LyricsLineView: View {
    let line: LyricsLine
    let isActive: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(line.text)
                .font(.system(size: isActive ? 21 : 18, weight: isActive ? .bold : .regular, design: .rounded))
                .foregroundStyle(isActive ? Color.white : Color.white.opacity(0.35))
                .scaleEffect(x: isActive ? 1.04 : 1.0, y: isActive ? 1.04 : 1.0, anchor: .leading)

            if !line.translation.isEmpty {
                Text(line.translation)
                    .font(.system(size: 12.5, weight: .regular, design: .rounded))
                    .foregroundStyle(isActive ? Color.white.opacity(0.65) : Color.white.opacity(0.2))
            }
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 7)
        .animation(.spring(response: 0.35, dampingFraction: 0.75), value: isActive)
    }
}

#Preview {
    VStack(alignment: .leading) {
        LyricsLineView(line: TrackLyrics.mock.lyrics[1], isActive: true)
        LyricsLineView(line: TrackLyrics.mock.lyrics[2], isActive: false)
    }
    .frame(width: 500)
    .background(Color.black)
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Views/OffsetAdjustView.swift
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Views/OffsetAdjustView.swift" << 'SWIFT_EOF'
import SwiftUI

// MARK: - Offset Adjust View

struct OffsetAdjustView: View {
    @AppStorage("userLyricsOffset") private var storedOffset: Double = 0.0
    @Binding var offset: Double

    private let step = 0.1

    var body: some View {
        HStack(spacing: 10) {
            Button {
                offset = max(-5.0, offset - step)
                storedOffset = offset
            } label: {
                Image(systemName: "minus")
                    .frame(width: 28, height: 28)
                    .glassCard(cornerRadius: 10, opacity: 0.22)
            }
            .buttonStyle(.plain)

            Text(offsetLabel)
                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white.opacity(0.85))
                .frame(width: 58)
                .padding(.vertical, 5)
                .glassCard(cornerRadius: 10, opacity: 0.15)

            Button {
                offset = min(5.0, offset + step)
                storedOffset = offset
            } label: {
                Image(systemName: "plus")
                    .frame(width: 28, height: 28)
                    .glassCard(cornerRadius: 10, opacity: 0.22)
            }
            .buttonStyle(.plain)

            Button {
                offset = 0.0
                storedOffset = 0.0
            } label: {
                Image(systemName: "arrow.counterclockwise")
                    .frame(width: 28, height: 28)
                    .glassCard(cornerRadius: 10, opacity: 0.15)
            }
            .buttonStyle(.plain)
            .opacity(offset == 0 ? 0.3 : 1.0)
        }
        .foregroundStyle(.white)
        .onAppear { offset = storedOffset }
    }

    private var offsetLabel: String {
        let sign = offset >= 0 ? "+" : ""
        return "\(sign)\(String(format: "%.1f", offset))s"
    }
}

#Preview {
    OffsetAdjustView(offset: .constant(0.3))
        .padding()
        .background(Color.black)
}
SWIFT_EOF

# ══════════════════════════════════════════════════════════════════════════════
# Views/LyricsView.swift  ← MAIN VIEW
# ══════════════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/Views/LyricsView.swift" << 'SWIFT_EOF'
import SwiftUI
import MusicKit

// MARK: - Main Lyrics View

struct LyricsView: View {
    @State private var provider  = LyricProvider()
    @State private var clock     = SyncClock()
    @State private var bgColors: [Color] = [
        Color(red: 0.05, green: 0.03, blue: 0.12),
        Color(red: 0.10, green: 0.04, blue: 0.18),
        Color(red: 0.03, green: 0.06, blue: 0.15),
    ]
    @State private var artwork: NSImage?
    @State private var offset: Double = 0.0
    @State private var showOffset = false
    @State private var gradientPhase: Float = 0

    // SwiftData context は ContentView等から Environment で渡す想定
    @Environment(\.modelContext) private var modelContext

    var body: some View {
        ZStack {
            // ── BACKGROUND: MeshGradient ──────────────────────────────────────
            meshBackground
                .ignoresSafeArea()

            // ── MAIN CONTENT ─────────────────────────────────────────────────
            VStack(spacing: 0) {
                headerBar
                lyricsScroll
                footerBar
            }
        }
        .onAppear {
            provider.configure(context: modelContext)
            clock.startMonitoring()
            setupMusicObserver()
        }
        .onDisappear {
            clock.stopMonitoring()
        }
        .onChange(of: clock.userOffset) { _, v in
            // ユーザーオフセットを同期
            clock.userOffset = offset
        }
        .onChange(of: offset) { _, v in
            clock.userOffset = v
        }
    }

    // MARK: - Sub-Views

    @ViewBuilder
    private var meshBackground: some View {
        let c = bgColors
        ZStack {
            // ベース: 濃い深紫ブラック
            Color(red: 0.03, green: 0.02, blue: 0.08)

            if #available(macOS 15.0, *) {
                // MeshGradient (macOS 15+)
                MeshGradient(
                    width: 3, height: 3,
                    points: [
                        [0.0, 0.0], [0.5, 0.0], [1.0, 0.0],
                        [0.0, 0.5], [0.5, 0.5], [1.0, 0.5],
                        [0.0, 1.0], [0.5, 1.0], [1.0, 1.0],
                    ],
                    colors: [
                        c[0], c[1], c[0],
                        c[1], c[2], c[1],
                        c[0], c[1], c[2],
                    ]
                )
                .opacity(0.75)
            } else {
                // fallback
                LinearGradient(
                    colors: c,
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .opacity(0.75)
            }
        }
    }

    @ViewBuilder
    private var headerBar: some View {
        HStack(spacing: 12) {
            // アートワーク
            if let art = artwork {
                Image(nsImage: art)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 42, height: 42)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    .shadow(color: .black.opacity(0.5), radius: 6, x: 0, y: 3)
            } else {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(Color.white.opacity(0.08))
                    .frame(width: 42, height: 42)
                    .overlay(Image(systemName: "music.note").foregroundStyle(.white.opacity(0.3)))
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(provider.lyrics?.title ?? "—")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)

                Text(provider.lyrics?.artist ?? "—")
                    .font(.system(size: 11, weight: .regular, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
                    .lineLimit(1)
            }

            Spacer()

            // ローディングインジケーター
            stateIndicator

            // オフセット調整トグル
            Button {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                    showOffset.toggle()
                }
            } label: {
                Image(systemName: "timer")
                    .frame(width: 32, height: 32)
                    .glassCard(cornerRadius: 10, opacity: 0.18)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white.opacity(0.8))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial.opacity(0.6))
    }

    @ViewBuilder
    private var stateIndicator: some View {
        switch provider.state {
        case .idle:
            EmptyView()
        case .loading:
            ProgressView()
                .controlSize(.small)
                .tint(.white)
        case .analyzing(let progress):
            Label(progress, systemImage: "waveform")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.white.opacity(0.7))
                .padding(.horizontal, 8).padding(.vertical, 4)
                .glassCard(cornerRadius: 8, opacity: 0.15)
        case .done:
            EmptyView()
        case .error(let msg):
            Label(msg, systemImage: "exclamationmark.triangle")
                .font(.system(size: 10))
                .foregroundStyle(.red.opacity(0.8))
                .lineLimit(1)
        }
    }

    @ViewBuilder
    private var lyricsScroll: some View {
        if let lyrics = provider.lyrics {
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        // 上パディング
                        Color.clear.frame(height: 120).id("top")

                        ForEach(lyrics.lyrics) { line in
                            let isActive = clock.currentLineIndex == line.lineIndex

                            Group {
                                if line.hasFavoriteWords {
                                    KaraokeLineView(
                                        line: line,
                                        currentTime: clock.currentTime,
                                        isActive: isActive,
                                        clock: clock
                                    )
                                } else {
                                    LyricsLineView(line: line, isActive: isActive)
                                }
                            }
                            .id(line.lineIndex)
                        }

                        // 下パディング
                        Color.clear.frame(height: 200)
                    }
                }
                .onChange(of: clock.currentLineIndex) { _, newIdx in
                    guard newIdx >= 0 else { return }
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                        proxy.scrollTo(newIdx, anchor: .center)
                    }
                }
            }
        } else {
            Spacer()
            emptyState
            Spacer()
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "music.note.list")
                .font(.system(size: 44))
                .foregroundStyle(.white.opacity(0.2))
            Text("曲を再生すると歌詞が表示されます")
                .font(.system(size: 14, design: .rounded))
                .foregroundStyle(.white.opacity(0.3))
        }
    }

    @ViewBuilder
    private var footerBar: some View {
        if showOffset {
            HStack {
                Text("タイミング補正")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
                Spacer()
                OffsetAdjustView(offset: $offset)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial.opacity(0.6))
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
    }

    // MARK: - Music Observer

    private func setupMusicObserver() {
        Task {
            for await entry in MusicKit.MusicPlayer.Queue.updates {
                guard let song = entry.currentEntry?.item as? Song else { continue }
                await MainActor.run {
                    loadNewSong(song)
                }
            }
        }
    }

    private func loadNewSong(_ song: Song) {
        // アートワーク取得 → 背景色更新
        Task {
            if let url = song.artwork?.url(width: 300, height: 300),
               let (data, _) = try? await URLSession.shared.data(from: url),
               let img = NSImage(data: data) {
                let colors = await MainActor.run { ColorExtractor.extract(from: img, count: 3) }
                withAnimation(.easeInOut(duration: 1.5)) {
                    bgColors = colors
                    artwork  = img
                }
            }

            let favorites: Set<String> = []  // SwiftDataからお気に入り判定に置き換え
            let isFav = favorites.contains(song.id.rawValue as? String ?? "")
            await provider.loadLyrics(for: song, isFavorite: isFav)
            if let lyr = provider.lyrics {
                clock.attach(lyrics: lyr)
            }
        }
    }
}

#Preview {
    LyricsView()
        .frame(width: 480, height: 700)
}
SWIFT_EOF

echo ""
echo "✅ クライアント Swiftファイル生成完了！"
echo ""
echo "ファイル一覧:"
find "$APP_DIR" -name "*.swift" | sort

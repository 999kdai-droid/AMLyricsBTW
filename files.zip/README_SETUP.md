# AMLyricsBTW — セットアップ手順

## 全体の流れ

```
iMac 2015 (サーバー)          MacBook/Mac (クライアント)
─────────────────             ─────────────────────────
setup_server.sh 実行    →     Xcode でプロジェクト作成
pip install                   setup_client.sh 実行
python main.py 起動           Xcode でビルド・実行
```

---

## 【STEP 1】スクリプトファイルをダウンロード・配置

```bash
# ホームにフォルダ作成
mkdir -p ~/AMLyricsBTW

# ダウンロードしたスクリプトを移動（ダウンロードフォルダから）
mv ~/Downloads/setup_server.sh ~/AMLyricsBTW/
mv ~/Downloads/setup_client.sh ~/AMLyricsBTW/
mv ~/Downloads/setup_xcode.sh  ~/AMLyricsBTW/

# 実行権限付与
chmod +x ~/AMLyricsBTW/*.sh
```

---

## 【STEP 2】サーバーセットアップ（iMac 2015 で実行）

### 2-1. 依存ツールのインストール（Homebrew）

```bash
# Homebrewインストール（未インストールの場合）
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# ffmpeg と yt-dlp
brew install ffmpeg yt-dlp

# Python 3.11（pyenvを使う場合）
brew install pyenv
pyenv install 3.11.9
pyenv global 3.11.9
echo 'export PATH="$(pyenv root)/shims:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

### 2-2. サーバーファイル生成

```bash
bash ~/AMLyricsBTW/setup_server.sh
```

### 2-3. 仮想環境・依存パッケージインストール

```bash
cd ~/AMLyricsBTW/server
python3 -m venv venv
source venv/bin/activate

# PyTorchはCPU版を明示（iMac 2015はGPUなし）
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu

# 残りのパッケージ
pip install fastapi "uvicorn[standard]" yt-dlp google-generativeai python-dotenv

# WhisperX（CPU版）
pip install git+https://github.com/m-bain/whisperX.git
```

### 2-4. APIキー設定

```bash
# .envを編集（nanoまたはお好みのエディタで）
nano ~/AMLyricsBTW/server/.env
```

`.env` の内容：
```
AMLYRICS_API_KEY=amlyrics_your_secret_key_here   ← 好きな文字列に変更
GEMINI_API_KEY=AIza...your_gemini_key_here        ← Google AI Studio から取得
WHISPER_MODEL=medium
CACHE_DIR=./cache
TEMP_DIR=/tmp/amlyrics
```

### 2-5. サーバー起動

```bash
cd ~/AMLyricsBTW/server
source venv/bin/activate
python main.py
```

### 2-6. サーバー起動確認（別のターミナルで）

```bash
# iMacのIPアドレスを確認
ipconfig getifaddr en0

# ヘルスチェック（IPを確認して変更）
curl http://localhost:8000/health

# 解析テスト（APIキーを設定したものに変更）
curl -X POST http://localhost:8000/analyze \
  -H "Content-Type: application/json" \
  -H "X-API-Key: amlyrics_your_secret_key_here" \
  -d '{"track_id":"test001","title":"N.Y. State of Mind","artist":"Nas","is_favorite":false}'
```

### 2-7. 自動起動設定（再起動後も自動起動）

```bash
cat > ~/Library/LaunchAgents/com.amlyrics.server.plist << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.amlyrics.server</string>
    <key>ProgramArguments</key>
    <array>
        <string>$HOME/AMLyricsBTW/server/venv/bin/python</string>
        <string>$HOME/AMLyricsBTW/server/main.py</string>
    </array>
    <key>WorkingDirectory</key>
    <string>$HOME/AMLyricsBTW/server</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$HOME/AMLyricsBTW/server/server.log</string>
    <key>StandardErrorPath</key>
    <string>$HOME/AMLyricsBTW/server/server.log</string>
</dict>
</plist>
PLIST

launchctl load ~/Library/LaunchAgents/com.amlyrics.server.plist
echo "✅ 自動起動設定完了"
```

---

## 【STEP 3】クライアントセットアップ（Xcodeで）

### 3-1. Xcodeプロジェクト作成

1. Xcodeを起動
2. **File > New > Project**
3. **macOS > App** を選択
4. 設定:
   - Product Name: `AMLyricsBTW`
   - Team: 自分のApple ID
   - Organization Identifier: `com.yourname`
   - Interface: **SwiftUI**
   - Language: **Swift**
   - ✅ **Use SwiftData** チェックON
5. `~/Developer/AMLyricsBTW` に保存

### 3-2. Swiftファイル生成

```bash
# Xcodeプロジェクトのパスを確認して実行
cd ~/Developer/AMLyricsBTW
bash ~/AMLyricsBTW/setup_client.sh AMLyricsBTW
```

### 3-3. Xcodeにファイルを追加

1. Xcodeのプロジェクトナビゲーターで **AMLyricsBTW** フォルダを右クリック
2. **Add Files to "AMLyricsBTW"...**
3. `~/Developer/AMLyricsBTW/AMLyricsBTW/` 内の以下フォルダを全て選択して追加:
   - `Models/`
   - `Views/`
   - `Managers/`
   - `SwiftData/`
   - `Utilities/`

### 3-4. Info.plist に権限追加

```bash
# Info.plistにApple Music使用許可を追加
/usr/libexec/PlistBuddy -c "Add :NSAppleMusicUsageDescription string '歌詞の同期表示のためにApple Musicへのアクセスが必要です'" \
  ~/Developer/AMLyricsBTW/AMLyricsBTW/Info.plist
```

### 3-5. MusicKit Capability 追加（Xcodeで手動）

1. Xcodeでプロジェクトを選択
2. **Target > AMLyricsBTW > Signing & Capabilities**
3. **+ Capability** ボタン
4. **MusicKit** を追加

### 3-6. ContentView.swift を書き換え

Xcode で `ContentView.swift` を開いて以下で完全に置き換え:

```swift
import SwiftUI
import SwiftData

@main
struct AMLyricsBTWApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .modelContainer(for: CachedLyrics.self)
        }
        .windowStyle(.hiddenTitleBar)
        .defaultSize(width: 480, height: 720)
    }
}

struct ContentView: View {
    var body: some View {
        LyricsView()
            .preferredColorScheme(.dark)
            .frame(minWidth: 380, minHeight: 500)
    }
}
```

### 3-7. サーバー接続設定

```bash
# Bundle IDをXcodeで確認してから実行（com.yourname.AMLyricsBTWの部分を変更）
defaults write com.yourname.AMLyricsBTW serverBaseURL 'http://192.168.1.100:8000'
defaults write com.yourname.AMLyricsBTW serverAPIKey  'amlyrics_your_secret_key_here'
```

---

## トラブルシューティング

### サーバーログ確認
```bash
tail -f ~/AMLyricsBTW/server/server.log
```

### キャッシュ削除（再解析したい場合）
```bash
rm ~/AMLyricsBTW/server/cache/TRACK_ID.json
```

### WhisperXがエラーになる場合
```bash
# モデルをsmallに切り替え
echo "WHISPER_MODEL=small" >> ~/AMLyricsBTW/server/.env
```

### yt-dlpが失敗する場合（定期的にアップデートが必要）
```bash
cd ~/AMLyricsBTW/server && source venv/bin/activate
pip install --upgrade yt-dlp
```

#!/bin/bash
# AMLyricsBTW — サーバーセットアップスクリプト
# iMac 2015 (macOS 15 Sequoia) で実行すること

set -e
echo "🎵 AMLyricsBTW サーバーセットアップ開始..."

mkdir -p ~/AMLyricsBTW/server/cache
cd ~/AMLyricsBTW/server

# ──────────────────────────────────────────────
# .env
# ──────────────────────────────────────────────
cat > .env << 'ENVEOF'
AMLYRICS_API_KEY=amlyrics_change_this_secret_key
GEMINI_API_KEY=your_gemini_api_key_here
WHISPER_MODEL=medium
CACHE_DIR=./cache
TEMP_DIR=/tmp/amlyrics
ENVEOF

# ──────────────────────────────────────────────
# requirements.txt
# ──────────────────────────────────────────────
cat > requirements.txt << 'EOF'
fastapi==0.115.0
uvicorn[standard]==0.30.6
whisperx==3.1.5
yt-dlp==2024.9.27
google-generativeai==0.8.2
python-dotenv==1.0.1
numpy<2.0
torch
torchaudio
EOF

# ──────────────────────────────────────────────
# config.py
# ──────────────────────────────────────────────
cat > config.py << 'EOF'
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY: str       = os.getenv("AMLYRICS_API_KEY", "change_me")
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
WHISPER_MODEL: str  = os.getenv("WHISPER_MODEL", "medium")   # "small" or "medium"
CACHE_DIR: str      = os.getenv("CACHE_DIR", "./cache")
TEMP_DIR: str       = os.getenv("TEMP_DIR", "/tmp/amlyrics")
EOF

# ──────────────────────────────────────────────
# cache.py
# ──────────────────────────────────────────────
cat > cache.py << 'EOF'
import json
import os
from pathlib import Path
from config import CACHE_DIR


def _cache_path(track_id: str) -> Path:
    return Path(CACHE_DIR) / f"{track_id}.json"


def load_cache(track_id: str) -> dict | None:
    p = _cache_path(track_id)
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def save_cache(track_id: str, data: dict) -> None:
    os.makedirs(CACHE_DIR, exist_ok=True)
    p = _cache_path(track_id)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
EOF

# ──────────────────────────────────────────────
# translator.py
# ──────────────────────────────────────────────
cat > translator.py << 'EOF'
import asyncio
import json
import google.generativeai as genai
from config import GEMINI_API_KEY

genai.configure(api_key=GEMINI_API_KEY)

SYSTEM_PROMPT = """あなたはアメリカン・ヒップホップの歌詞を日本語に意訳する専門家です。
主に90年代〜2000年代のEast/West Coast Hip-Hop（Nas, 2Pac, Jay-Z, Biggie, Eminem, Wu-Tang Clan等）を扱います。

【翻訳スタイル】
- AAVE（African American Vernacular English）のスラングや文法を正確に解釈する
- 逐語訳・直訳を避け、日本語として自然でリズム感のある意訳を行う
- ストリート用語（beef, getting money, ride or die, cap等）は文脈に合った自然な日本語にする
- 聖書・神話・ストリート文化への参照は注記せず意訳に溶け込ませる
- 性的・暴力的表現も意味を損なわず日本語として自然な表現にする
- 固有名詞（地名・人名・ブランド）はそのままカタカナ表記

【出力形式（厳守）】
- 入力: 番号付き行リスト（例: "1. It was all a dream"）
- 出力: JSONのみ。マークダウン記法（```等）は絶対に使わない
- 行数は入力と必ず一致させる
- 意訳不能な行（コーラス記号等）は原文をそのままカタカナで返す
- 余計な説明・注釈は一切含めない
- 推量表現（〜でしょう、〜と思われます）禁止
- メタコメント（原文では〜）禁止

出力形式:
{"translations": ["意訳1", "意訳2", "意訳3"]}"""


async def translate_lyrics(lines: list[str]) -> list[str]:
    """歌詞の行リストを受け取り、日本語意訳リストを返す。最大3回リトライ。"""
    if not lines:
        return []

    numbered = "\n".join(f"{i + 1}. {line}" for i, line in enumerate(lines))
    model = genai.GenerativeModel(
        model_name="gemini-1.5-pro",
        system_instruction=SYSTEM_PROMPT,
    )

    for attempt in range(3):
        try:
            response = await asyncio.to_thread(model.generate_content, numbered)
            text = response.text.strip()
            # マークダウン除去（念のため）
            text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            data = json.loads(text)
            translations: list[str] = data["translations"]
            if len(translations) != len(lines):
                raise ValueError(
                    f"行数不一致: 入力={len(lines)}, 出力={len(translations)}"
                )
            return translations
        except Exception as exc:
            if attempt < 2:
                wait = 2 ** (attempt + 1)
                print(f"[translator] リトライ {attempt + 1}/3 ({wait}s待機): {exc}")
                await asyncio.sleep(wait)
            else:
                print(f"[translator] 翻訳失敗。空文字列でフォールバック: {exc}")
                return [""] * len(lines)
EOF

# ──────────────────────────────────────────────
# analyzer.py
# ──────────────────────────────────────────────
cat > analyzer.py << 'EOF'
import asyncio
import os
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import whisperx
from config import WHISPER_MODEL, TEMP_DIR
from translator import translate_lyrics


# ─── yt-dlp ──────────────────────────────────────────────────────────────────

async def download_audio(title: str, artist: str) -> str:
    """yt-dlpでYouTubeから音声をDLしてWAVパスを返す。"""
    os.makedirs(TEMP_DIR, exist_ok=True)
    query = f"ytsearch1:{title} {artist} lyrics audio"
    out_template = os.path.join(TEMP_DIR, "%(id)s.%(ext)s")

    cmd = [
        "yt-dlp",
        "--no-playlist",
        "-x", "--audio-format", "wav",
        "--audio-quality", "0",
        "--postprocessor-args", "ffmpeg:-ar 16000 -ac 1",
        "-o", out_template,
        query,
    ]

    result = await asyncio.to_thread(
        subprocess.run, cmd, capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"yt-dlp失敗: {result.stderr[:500]}")

    # DLされたWAVを探す
    for f in Path(TEMP_DIR).glob("*.wav"):
        return str(f)
    raise FileNotFoundError("WAVファイルが見つかりません")


# ─── ffmpeg 無音検知 ──────────────────────────────────────────────────────────

async def detect_silence_offset(wav_path: str) -> float:
    """音源冒頭の silence_end（秒）を返す。検出失敗時は0.0。"""
    cmd = [
        "ffmpeg", "-i", wav_path,
        "-af", "silencedetect=noise=-35dB:duration=0.3",
        "-f", "null", "-",
    ]
    result = await asyncio.to_thread(
        subprocess.run, cmd, capture_output=True, text=True
    )
    # ffmpegはstderrに出力する
    output = result.stderr
    matches = re.findall(r"silence_end: ([\d.]+)", output)
    if matches:
        return float(matches[0])
    return 0.0


# ─── WhisperX 解析 ────────────────────────────────────────────────────────────

async def run_whisperx(
    wav_path: str, is_favorite: bool
) -> tuple[list[dict], str]:
    """WhisperXでトランスクリプトを取得。(segments, language)を返す。"""

    def _run() -> tuple[list[dict], str]:
        model = whisperx.load_model(
            WHISPER_MODEL,
            device="cpu",
            compute_type="int8",
        )
        audio = whisperx.load_audio(wav_path)
        result = model.transcribe(audio, batch_size=4)
        language = result.get("language", "en")

        if is_favorite:
            # 単語レベルタイムスタンプ
            align_model, metadata = whisperx.load_align_model(
                language_code=language, device="cpu"
            )
            result = whisperx.align(
                result["segments"],
                align_model,
                metadata,
                audio,
                device="cpu",
                return_char_alignments=False,
            )

        return result["segments"], language

    segments, language = await asyncio.to_thread(_run)
    return segments, language


# ─── メイン解析エントリポイント ───────────────────────────────────────────────

async def analyze_track(
    track_id: str,
    title: str,
    artist: str,
    is_favorite: bool,
) -> dict[str, Any]:
    """
    1. yt-dlpで音声DL
    2. ffmpegで無音オフセット検出
    3. WhisperX解析
    4. Geminiで意訳
    5. マスタープロンプト仕様のJSONを返す
    """
    wav_path: str | None = None
    try:
        print(f"[analyzer] DL開始: {title} / {artist}")
        wav_path = await download_audio(title, artist)

        print(f"[analyzer] 無音検知: {wav_path}")
        silence_offset = await detect_silence_offset(wav_path)
        print(f"[analyzer] silence_offset={silence_offset:.3f}s")

        print(f"[analyzer] WhisperX解析 (model={WHISPER_MODEL}, favorite={is_favorite})")
        segments, _lang = await run_whisperx(wav_path, is_favorite)

        # セグメント → 行リスト（オフセット補正済み）
        lyrics_lines: list[dict] = []
        raw_texts: list[str] = []

        for idx, seg in enumerate(segments):
            raw_start = float(seg.get("start", 0.0))
            raw_end   = float(seg.get("end",   0.0))
            text      = seg.get("text", "").strip()

            start = max(0.0, raw_start - silence_offset)
            end   = max(0.0, raw_end   - silence_offset)

            words_data: list[dict] = []
            if is_favorite and "words" in seg:
                for w in seg["words"]:
                    w_start = max(0.0, float(w.get("start", 0.0)) - silence_offset)
                    w_end   = max(0.0, float(w.get("end",   0.0)) - silence_offset)
                    words_data.append({
                        "word":  w.get("word", ""),
                        "start": round(w_start, 3),
                        "end":   round(w_end,   3),
                    })

            entry: dict = {
                "line_index":  idx,
                "start":       round(start, 3),
                "end":         round(end,   3),
                "text":        text,
                "translation": "",
            }
            if words_data:
                entry["words"] = words_data

            lyrics_lines.append(entry)
            raw_texts.append(text)

        # 意訳
        print(f"[analyzer] Gemini意訳 ({len(raw_texts)}行)")
        translations = await translate_lyrics(raw_texts)
        for i, t in enumerate(translations):
            lyrics_lines[i]["translation"] = t

        return {
            "track_id":       track_id,
            "title":          title,
            "artist":         artist,
            "silence_offset": round(silence_offset, 3),
            "lyrics":         lyrics_lines,
        }

    finally:
        if wav_path and os.path.exists(wav_path):
            os.remove(wav_path)
            print(f"[analyzer] 一時ファイル削除: {wav_path}")
EOF

# ──────────────────────────────────────────────
# queue_manager.py
# ──────────────────────────────────────────────
cat > queue_manager.py << 'EOF'
import asyncio
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from analyzer import analyze_track
from cache import save_cache


class JobStatus(str, Enum):
    QUEUED     = "queued"
    PROCESSING = "processing"
    DONE       = "done"
    ERROR      = "error"


@dataclass
class Job:
    job_id:      str
    track_id:    str
    title:       str
    artist:      str
    is_favorite: bool
    status:      JobStatus = JobStatus.QUEUED
    result:      Any       = None
    error:       str       = ""


# グローバルキューとジョブストア
_queue: asyncio.Queue[Job]       = asyncio.Queue()
_jobs:  dict[str, Job]           = {}
_current_job: Job | None         = None


def create_job(track_id: str, title: str, artist: str, is_favorite: bool) -> Job:
    job = Job(
        job_id      = str(uuid.uuid4()),
        track_id    = track_id,
        title       = title,
        artist      = artist,
        is_favorite = is_favorite,
    )
    _jobs[job.job_id] = job
    _queue.put_nowait(job)
    return job


def get_job(job_id: str) -> Job | None:
    return _jobs.get(job_id)


def get_queue_info() -> dict:
    return {
        "waiting":     _queue.qsize(),
        "current":     _current_job.title if _current_job else None,
        "total_jobs":  len(_jobs),
    }


async def _worker() -> None:
    """キューからジョブを1つずつ処理するバックグラウンドタスク。"""
    global _current_job
    while True:
        job: Job = await _queue.get()
        _current_job = job
        job.status = JobStatus.PROCESSING
        print(f"[queue] 処理開始: {job.title} / {job.artist} (job_id={job.job_id})")

        try:
            result = await analyze_track(
                track_id    = job.track_id,
                title       = job.title,
                artist      = job.artist,
                is_favorite = job.is_favorite,
            )
            job.result = result
            job.status = JobStatus.DONE
            save_cache(job.track_id, result)
            print(f"[queue] 完了: {job.title}")
        except Exception as exc:
            job.status = JobStatus.ERROR
            job.error  = str(exc)
            print(f"[queue] エラー: {job.title} — {exc}")
        finally:
            _current_job = None
            _queue.task_done()


async def start_worker() -> None:
    asyncio.create_task(_worker())
EOF

# ──────────────────────────────────────────────
# main.py
# ──────────────────────────────────────────────
cat > main.py << 'EOF'
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Path
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import cache as cache_module
import queue_manager as qm
from config import API_KEY


# ─── 認証ヘルパー ──────────────────────────────────────────────────────────────

def verify_api_key(x_api_key: str = Header(...)) -> None:
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")


# ─── Pydanticモデル ────────────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    track_id:    str
    title:       str
    artist:      str
    is_favorite: bool = False


class JobResponse(BaseModel):
    job_id: str
    status: str


# ─── lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    await qm.start_worker()
    print("🎵 AMLyricsBTW サーバー起動")
    yield
    print("🛑 サーバー停止")


# ─── FastAPIアプリ ─────────────────────────────────────────────────────────────

app = FastAPI(title="AMLyricsBTW", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── エンドポイント ────────────────────────────────────────────────────────────

@app.post("/analyze", response_model=JobResponse)
async def analyze(req: AnalyzeRequest, x_api_key: str = Header(...)) -> JobResponse:
    verify_api_key(x_api_key)

    # 既にキャッシュがある場合はスキップ
    cached = cache_module.load_cache(req.track_id)
    if cached:
        return JobResponse(job_id="cached", status="done")

    job = qm.create_job(
        track_id    = req.track_id,
        title       = req.title,
        artist      = req.artist,
        is_favorite = req.is_favorite,
    )
    return JobResponse(job_id=job.job_id, status=job.status.value)


@app.get("/status/{job_id}")
async def get_status(
    job_id: str = Path(...),
    x_api_key: str = Header(...),
) -> dict[str, Any]:
    verify_api_key(x_api_key)

    job = qm.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    response: dict[str, Any] = {"job_id": job.job_id, "status": job.status.value}
    if job.status == qm.JobStatus.DONE:
        response["result"] = job.result
    elif job.status == qm.JobStatus.ERROR:
        response["error"] = job.error
    return response


@app.get("/cache/{track_id}")
async def get_cache(
    track_id: str = Path(...),
    x_api_key: str = Header(...),
) -> dict[str, Any]:
    verify_api_key(x_api_key)

    data = cache_module.load_cache(track_id)
    if not data:
        raise HTTPException(status_code=404, detail="Cache not found")
    return data


@app.get("/queue")
async def get_queue(x_api_key: str = Header(...)) -> dict[str, Any]:
    verify_api_key(x_api_key)
    return qm.get_queue_info()


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


# ─── 起動エントリポイント ──────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
EOF

echo ""
echo "✅ サーバーファイル生成完了！"
echo ""
echo "次のステップ:"
echo "  cd ~/AMLyricsBTW/server"
echo "  python3 -m venv venv"
echo "  source venv/bin/activate"
echo "  pip install -r requirements.txt"
echo "  # .envのAPIキーを設定してから:"
echo "  python main.py"
